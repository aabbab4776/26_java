package day02;

public class HELLO {

	public static void main(String[] args) {
		
		
		//System.out.println("Hello JAVA--");
		//System.out.println("이동혁");
		System.out.print("반갑습니다, 열심히 java 공부해요.\n줄바꿈\n");
		System.out.print("반갑습니다, 열심히 java 공부해요.\n줄바꿈\n");
		//System.out.println("정보보안학과20251313");
		
		
		
		
		
		
		

	}

}
