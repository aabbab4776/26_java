package day02;

public class HELLO0310 {

	public static void main(String[] args) {
		System.out.println("java로 하고 싶은것\n\n");
		
		System.out.print("국정원 해킹");
		
		
		
		
		
		

	}

}
