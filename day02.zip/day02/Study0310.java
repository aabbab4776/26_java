package day02;

public class Study0310 {

	public static void main(String[] args) {
		
		//1.기본형
		
		boolean isTrue;
		
		int age;
		
		double height,weight;
		
		//2.변수 초기화
		isTrue = false;
		
		age = 21;
		
		height = 173;
		
		weight = 78;
		
		String addr = new String("대전광역시 유성구 (*&(*&");
		
		//2.레퍼런스형(배열. class, interface)
		
		String name = "이동혁";		
		
		String s = new String("홍길동");
		
		Study0310 dtt = new Study0310();
		
		//3.출력

	System.out.println("boolean : " + isTrue);
	
	System.out.println("나이 : " + age);
	
	System.out.println("키 : " + height);
	
	System.out.println("몸무게 : " + weight);
	
	System.out.println("이름 : " + name);

	System.out.println("주소 : " + addr);
	
	
	}

}
